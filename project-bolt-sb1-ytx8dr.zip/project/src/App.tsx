import React, { useEffect, useState } from 'react';
import { CalendarForm } from './components/CalendarForm';
import { generatePDF } from './components/PDFGenerator';
import { loadHolidays } from './utils/calendar';
import { Holiday, CalendarSettings } from './types/calendar';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { InfoSection } from './components/InfoSection';

function App() {
  const [holidays, setHolidays] = useState<Holiday[]>([]);
  const [language, setLanguage] = useState<'en' | 'uk'>('uk');

  useEffect(() => {
    loadHolidays().then(setHolidays);
  }, []);

  const handleGenerate = async (month: number, year: number, notes: string, settings: CalendarSettings) => {
    setLanguage(settings.language);
    await generatePDF({ month, year, notes, holidays, settings });
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <Header language={language} />

        <div className="bg-white shadow rounded-lg p-6">
          <CalendarForm onGenerate={handleGenerate} />
        </div>

        <div className="mt-8 text-center text-sm text-gray-500">
          <p>
            {language === 'uk' 
              ? 'Святкові дні автоматично виділяються рожевим кольором' 
              : 'Holidays are automatically highlighted in pink'}
          </p>
          <p>
            {language === 'uk'
              ? 'Зображення для кожного місяця взяті з Unsplash'
              : 'Images for each month are sourced from Unsplash'}
          </p>
        </div>

        <InfoSection />
        <Footer language={language} />
      </div>
    </div>
  );
}

export default App;