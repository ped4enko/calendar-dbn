export interface Holiday {
  date: string;
  name: string;
}

export interface CalendarEvent {
  date: string;
  title: string;
  description?: string;
}

export interface MonthImage {
  month: number;
  imageUrl: string;
}

export interface CalendarSettings {
  language: 'en' | 'uk';
  weekStartsOn: 0 | 1; // 0 for Sunday, 1 for Monday
}

export interface CalendarFormData {
  month: number;
  year: number;
  notes: string;
  settings: CalendarSettings;
}