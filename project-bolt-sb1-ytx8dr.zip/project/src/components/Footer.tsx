import React from 'react';

interface FooterProps {
  language: 'en' | 'uk';
}

export const Footer: React.FC<FooterProps> = ({ language }) => (
  <footer className="mt-8 text-center text-sm text-gray-500">
    <p>
      Розроблено для сайту <a href="https://dbn.co.ua/" className="text-blue-600 hover:text-blue-800 underline" target="_blank" rel="noopener noreferrer">ДБНУ</a>
    </p>
  </footer>
);