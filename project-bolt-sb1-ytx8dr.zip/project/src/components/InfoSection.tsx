import React from 'react';

export const InfoSection: React.FC = () => (
  <>
    <section className="mt-8">
      <p className="text-gray-700">Ласкаво просимо до нашого безкоштовного онлайн-генератора календарів! Якщо ви шукаєте швидкий і простий спосіб <strong>створити календар онлайн 2025 українською</strong> або <strong>шаблон календаря 2025</strong> для друку, ви знайшли ідеальний інструмент.</p>
    </section>

    <section className="mt-6">
      <h2 className="text-xl font-bold text-gray-900 mb-3">Що ви можете створити?</h2>
      <ul className="list-disc pl-5 space-y-2 text-gray-700">
        <li><strong>Щомісячний календар:</strong> Зручний формат для планування подій або відстеження важливих дат.</li>
        <li><strong>Річний календар:</strong> Огляд усього року на одній сторінці.</li>
        <li><strong>Календар з фотографіями:</strong> Додайте улюблені фото, щоб зробити календар особливим.</li>
        <li><strong>Календар зі святами:</strong> Додаємо офіційні свята України та інші події.</li>
      </ul>
    </section>

    <section className="mt-6">
      <h2 className="text-xl font-bold text-gray-900 mb-3">Як зробити календар за допомогою нашого сервісу?</h2>
      <ol className="list-decimal pl-5 space-y-2 text-gray-700">
        <li><strong>Обирайте формат:</strong> Виберіть потрібний формат календаря.</li>
        <li><strong>Налаштуйте зовнішній вигляд:</strong> Введіть місяць, рік, додайте події.</li>
        <li><strong>Скачайте календар:</strong> Натисніть кнопку "Створити", і ваш PDF-календар готовий до завантаження.</li>
      </ol>
    </section>
  </>
);