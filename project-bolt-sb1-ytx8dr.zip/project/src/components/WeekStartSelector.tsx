import React from 'react';
import { Calendar } from 'lucide-react';
import { CalendarSettings } from '../types/calendar';

interface WeekStartSelectorProps {
  settings: CalendarSettings;
  onSettingsChange: (settings: CalendarSettings) => void;
}

export const WeekStartSelector: React.FC<WeekStartSelectorProps> = ({ settings, onSettingsChange }) => (
  <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
    <Calendar className="w-5 h-5 text-gray-600" />
    <select
      value={settings.weekStartsOn}
      onChange={(e) => onSettingsChange({ ...settings, weekStartsOn: Number(e.target.value) as 0 | 1 })}
      className="flex-1 bg-transparent border-none focus:ring-0"
    >
      <option value="1">{settings.language === 'uk' ? 'Початок тижня: Понеділок' : 'Week starts: Monday'}</option>
      <option value="0">{settings.language === 'uk' ? 'Початок тижня: Неділя' : 'Week starts: Sunday'}</option>
    </select>
  </div>
);