import pdfMake from 'pdfmake/build/pdfmake';
import { getDaysInMonth, startOfMonth, getDay } from 'date-fns';
import { Holiday, CalendarSettings } from '../types/calendar';
import { getMonthImage, isHoliday, formatMonth, getDayNames } from '../utils/calendar';
import { TDocumentDefinitions } from 'pdfmake/interfaces';

// Define fonts
const fonts = {
  Roboto: {
    normal: 'https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Me5Q.ttf',
    bold: 'https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlvAw.ttf',
  }
};

// Initialize pdfMake with fonts
pdfMake.fonts = fonts;

interface PDFGeneratorProps {
  month: number;
  year: number;
  notes: string;
  holidays: Holiday[];
  settings: CalendarSettings;
}

export const generatePDF = async ({ month, year, notes, holidays, settings }: PDFGeneratorProps) => {
  const date = new Date(year, month - 1);
  const monthName = formatMonth(date, settings.language);
  const daysInMonth = getDaysInMonth(date);
  let firstDay = getDay(startOfMonth(date));

  if (settings.weekStartsOn === 1) {
    firstDay = firstDay === 0 ? 6 : firstDay - 1;
  }

  // Get and convert month image to base64
  const imageUrl = getMonthImage(date);
  const imageResponse = await fetch(`${imageUrl}?w=800&q=80&fit=crop`);
  const imageBlob = await imageResponse.blob();
  const imageBase64 = await new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.readAsDataURL(imageBlob);
  });

  const days = getDayNames(settings);
  const calendarBody: any[][] = [days.map(day => ({ text: day, style: 'dayHeader' }))];
  
  let currentDay = 1;
  let currentWeek: any[] = Array(7).fill('');

  // Fill in empty cells before the first day
  for (let i = 0; i < firstDay; i++) {
    currentWeek[i] = { text: '', style: 'day' };
  }

  // Fill in the days
  for (let i = firstDay; currentDay <= daysInMonth; i++) {
    const currentDate = new Date(year, month - 1, currentDay);
    const isHolidayDay = isHoliday(currentDate, holidays);
    
    currentWeek[i % 7] = {
      text: currentDay.toString(),
      style: 'day',
      fillColor: isHolidayDay ? '#ffe6e6' : undefined
    };

    if (i % 7 === 6) {
      calendarBody.push([...currentWeek]);
      currentWeek = Array(7).fill('');
    }

    currentDay++;
  }

  // Add the last week if it's not complete
  if (currentWeek.some(cell => cell !== '')) {
    calendarBody.push([...currentWeek]);
  }

  const docDefinition: TDocumentDefinitions = {
    info: {
      title: `Calendar - ${monthName}`,
      author: 'ДБНУ dbn.co.ua',
      subject: 'Щомісячний календар з українськими святами',
      creator: 'ДБНУ dbn.co.ua'
    },
    pageSize: 'A4',
    pageOrientation: 'portrait',
    content: [
      {
        image: imageBase64,
        width: 500,
        alignment: 'center',
        margin: [0, 0, 0, 20]
      },
      { text: monthName, style: 'header' },
      {
        table: {
          headerRows: 1,
          widths: Array(7).fill('*'),
          body: calendarBody
        },
        layout: {
          hLineWidth: () => 1,
          vLineWidth: () => 1,
          hLineColor: () => '#dddddd',
          vLineColor: () => '#dddddd',
          paddingTop: () => 5,
          paddingBottom: () => 5
        }
      },
      notes ? [
        { text: '\n' },
        { text: settings.language === 'uk' ? 'Нотатки:' : 'Notes:', style: 'notesHeader' },
        { text: notes, style: 'notes' }
      ] : [],
      { text: 'розроблено для сайту ДБНУ https://dbn.co.ua/', style: 'footer' }
    ],
    defaultStyle: {
      font: 'Roboto'
    },
    styles: {
      header: {
        fontSize: 24,
        bold: true,
        alignment: 'center',
        margin: [0, 0, 0, 20]
      },
      dayHeader: {
        fontSize: 12,
        bold: true,
        alignment: 'center'
      },
      day: {
        fontSize: 12,
        alignment: 'center'
      },
      notesHeader: {
        fontSize: 14,
        bold: true,
        margin: [0, 10, 0, 5]
      },
      notes: {
        fontSize: 12,
        margin: [0, 0, 0, 10]
      },
      footer: {
        fontSize: 8,
        color: '#ffffff',
        alignment: 'center',
        margin: [0, 20, 0, 0]
      }
    }
  };

  pdfMake.createPdf(docDefinition).download(`calendar-${monthName.toLowerCase()}.pdf`);
};