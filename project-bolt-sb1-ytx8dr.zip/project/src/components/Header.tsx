import React from 'react';
import { Calendar } from 'lucide-react';

interface HeaderProps {
  language: 'en' | 'uk';
}

export const Header: React.FC<HeaderProps> = ({ language }) => (
  <div className="text-center mb-8">
    <Calendar className="w-12 h-12 mx-auto text-blue-600" />
    <h1 className="mt-4 text-4xl font-bold text-gray-900">
      {language === 'uk' ? 'Генератор PDF Календаря' : 'Calendar PDF Generator'}
    </h1>
    <p className="mt-2 text-lg text-gray-600">
      {language === 'uk' 
        ? 'Створюйте гарні календарі з нотатками та святковими днями' 
        : 'Create beautiful calendars with custom notes and holiday highlights'}
    </p>
  </div>
);