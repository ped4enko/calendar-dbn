import React from 'react';
import { Languages } from 'lucide-react';
import { CalendarSettings } from '../types/calendar';

interface LanguageSelectorProps {
  settings: CalendarSettings;
  onSettingsChange: (settings: CalendarSettings) => void;
}

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({ settings, onSettingsChange }) => (
  <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
    <Languages className="w-5 h-5 text-gray-600" />
    <select
      value={settings.language}
      onChange={(e) => onSettingsChange({ ...settings, language: e.target.value as 'en' | 'uk' })}
      className="flex-1 bg-transparent border-none focus:ring-0"
    >
      <option value="uk">Українська</option>
      <option value="en">English</option>
    </select>
  </div>
);