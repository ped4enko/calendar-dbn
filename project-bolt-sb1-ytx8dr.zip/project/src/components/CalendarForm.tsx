import React, { useState } from 'react';
import { Calendar, Languages, Calendar as CalendarIcon } from 'lucide-react';
import { CalendarSettings } from '../types/calendar';
import { getLocale } from '../utils/calendar';

interface CalendarFormProps {
  onGenerate: (month: number, year: number, notes: string, settings: CalendarSettings) => void;
}

export const CalendarForm: React.FC<CalendarFormProps> = ({ onGenerate }) => {
  // Get current date for initialization
  const now = new Date();
  const currentDay = now.getDate();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();

  // Determine default month based on the date condition
  const defaultMonth = currentDay >= 15 ? currentMonth + 1 : currentMonth;
  // Adjust year if we need to move to January of next year
  const defaultYear = defaultMonth > 12 ? currentYear + 1 : currentYear;
  // Normalize month if it exceeds 12
  const normalizedDefaultMonth = defaultMonth > 12 ? 1 : defaultMonth;

  const [month, setMonth] = useState(normalizedDefaultMonth);
  const [year, setYear] = useState(defaultYear);
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState<CalendarSettings>({
    language: 'uk', // Set Ukrainian as default
    weekStartsOn: 1  // Set Monday as default
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onGenerate(month, year, notes, settings);
    } finally {
      setLoading(false);
    }
  };

  const locale = getLocale(settings.language);

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
          <Languages className="w-5 h-5 text-gray-600" />
          <select
            value={settings.language}
            onChange={(e) => setSettings(prev => ({ ...prev, language: e.target.value as 'en' | 'uk' }))}
            className="flex-1 bg-transparent border-none focus:ring-0"
          >
            <option value="uk">Українська</option>
            <option value="en">English</option>
          </select>
        </div>

        <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
          <CalendarIcon className="w-5 h-5 text-gray-600" />
          <select
            value={settings.weekStartsOn}
            onChange={(e) => setSettings(prev => ({ ...prev, weekStartsOn: Number(e.target.value) as 0 | 1 }))}
            className="flex-1 bg-transparent border-none focus:ring-0"
          >
            <option value="1">{settings.language === 'uk' ? 'Початок тижня: Понеділок' : 'Week starts: Monday'}</option>
            <option value="0">{settings.language === 'uk' ? 'Початок тижня: Неділя' : 'Week starts: Sunday'}</option>
          </select>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <div className="flex-1">
          <label htmlFor="month" className="block text-sm font-medium text-gray-700">
            {settings.language === 'uk' ? 'Місяць' : 'Month'}
          </label>
          <select
            id="month"
            value={month}
            onChange={(e) => setMonth(Number(e.target.value))}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            {Array.from({ length: 12 }, (_, i) => (
              <option key={i + 1} value={i + 1}>
                {new Date(2024, i).toLocaleString(settings.language, { month: 'long', locale })}
              </option>
            ))}
          </select>
        </div>

        <div className="flex-1">
          <label htmlFor="year" className="block text-sm font-medium text-gray-700">
            {settings.language === 'uk' ? 'Рік' : 'Year'}
          </label>
          <input
            type="number"
            id="year"
            value={year}
            onChange={(e) => setYear(Number(e.target.value))}
            min="1900"
            max="2100"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
      </div>

      <div>
        <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
          {settings.language === 'uk' ? 'Нотатки' : 'Notes'}
        </label>
        <textarea
          id="notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={4}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          placeholder={settings.language === 'uk' ? 'Додайте нотатки до календаря...' : 'Add any notes for the calendar...'}
        />
      </div>

      <button
        type="submit"
        disabled={loading}
        className={`flex items-center justify-center w-full px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
          loading ? 'opacity-75 cursor-not-allowed' : ''
        }`}
      >
        <Calendar className="w-5 h-5 mr-2" />
        {loading
          ? (settings.language === 'uk' ? 'Генерація...' : 'Generating...')
          : (settings.language === 'uk' ? 'Згенерувати Календар' : 'Generate Calendar')}
      </button>
    </form>
  );
};