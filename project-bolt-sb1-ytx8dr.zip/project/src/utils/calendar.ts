import { parse } from 'papaparse';
import { format, getMonth } from 'date-fns';
import { uk, enUS } from 'date-fns/locale';
import { Holiday, MonthImage, CalendarSettings } from '../types/calendar';

// Ukrainian month names in nominative case
const ukrainianMonths = [
  'Січень', 'Лютий', 'Березень', 'Квітень', 'Травень', 'Червень',
  'Липень', 'Серпень', 'Вересень', 'Жовтень', 'Листопад', 'Грудень'
];

// Full names of days in Ukrainian with properly escaped apostrophe
const ukrainianDays = [
  'Неділя', 'Понеділок', 'Вівторок', 'Середа', 'Четвер', 'П\u2019ятниця', 'Субота'
];

export const monthImages: MonthImage[] = [
  { month: 0, imageUrl: 'https://images.unsplash.com/photo-1483664852095-d6cc6870702d' },
  { month: 1, imageUrl: 'https://images.unsplash.com/photo-1518156677180-95a2893f3e9f' },
  { month: 2, imageUrl: 'https://images.unsplash.com/photo-1615651885088-3c20e7d84d3f' },
  { month: 3, imageUrl: 'https://images.unsplash.com/photo-1462275646964-a0e3386b89fa' },
  { month: 4, imageUrl: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352' },
  { month: 5, imageUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef' },
  { month: 6, imageUrl: 'https://images.unsplash.com/photo-1473496169904-658ba7c44d8a' },
  { month: 7, imageUrl: 'https://images.unsplash.com/photo-1535732820275-9ffd998cac22' },
  { month: 8, imageUrl: 'https://images.unsplash.com/photo-1507371341162-763b5e419408' },
  { month: 9, imageUrl: 'https://images.unsplash.com/photo-1507489989436-4d262adc915c' },
  { month: 10, imageUrl: 'https://images.unsplash.com/photo-1510901340205-7176dca5b229' },
  { month: 11, imageUrl: 'https://images.unsplash.com/photo-1512389142860-9c449e58a543' }
];

export const loadHolidays = async (): Promise<Holiday[]> => {
  const response = await fetch('/src/data/holidays.csv');
  const csv = await response.text();
  const { data } = parse(csv, { header: true });
  return data as Holiday[];
};

export const isHoliday = (date: Date, holidays: Holiday[]): boolean => {
  const dateStr = format(date, 'yyyy-MM-dd');
  return holidays.some(holiday => holiday.date === dateStr);
};

export const getMonthImage = (date: Date): string => {
  const month = getMonth(date);
  return monthImages[month].imageUrl;
};

export const getLocale = (language: 'en' | 'uk') => {
  return language === 'uk' ? uk : enUS;
};

export const formatMonth = (date: Date, language: 'en' | 'uk'): string => {
  if (language === 'uk') {
    const month = getMonth(date);
    return `${ukrainianMonths[month]} ${date.getFullYear()}`;
  }
  return format(date, 'MMMM yyyy', { locale: enUS });
};

export const getDayNames = (settings: CalendarSettings): string[] => {
  if (settings.language === 'uk') {
    const days = [...ukrainianDays];
    if (settings.weekStartsOn === 1) {
      days.push(days.shift()!);
    }
    return days;
  }

  const locale = enUS;
  return Array.from({ length: 7 }, (_, i) => {
    const day = (i + settings.weekStartsOn) % 7;
    return format(new Date(2024, 0, day + 1), 'EEEE', { locale });
  });
};